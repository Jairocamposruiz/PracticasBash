# !/bin/bash

#En este archivo recuperamos el nombre de otro script anterior

echo "EL nombre importado es: $nombre"
