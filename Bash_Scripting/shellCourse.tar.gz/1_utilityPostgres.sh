# !/bin/bash
# Programa para realizar algunas operaciones utilitarias de Postgres

nombre=Jairo

echo "Hola $nombre bienvenido al curso de Programación en Bash"
