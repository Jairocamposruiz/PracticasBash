# ! /bin/bash

option=$1
result=$2

echo "Option = $option"
echo "Result = $result"
